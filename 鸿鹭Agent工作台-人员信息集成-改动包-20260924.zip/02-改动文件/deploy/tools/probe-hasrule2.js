const puppeteer = require('puppeteer-core');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const b = await puppeteer.launch({
    executablePath: EDGE, headless: true, args: ['--no-sandbox'],
    defaultViewport: { width: 1440, height: 900 },
  });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', (e) => errs.push(String(e).slice(0, 140)));
  await p.goto('http://127.0.0.1:4080/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await sleep(14000);

  // A) 旧规则是否还在（应当为 0：新代码不再有那条 :has()）
  const ruleCount = await p.evaluate(() => {
    const s = document.querySelector('style[data-wb-style="1"]');
    return s ? (s.textContent.match(/list[^{]*:has\(/g) || []).length : -1;
  });

  // B) 模拟剔除：给两条会话行打标记（含包裹层判定），看会不会误伤
  const r = await p.evaluate(() => {
    const sec = [...document.querySelectorAll('[class*="groupSection"]')].find((s) => s.querySelectorAll('[class*="sessionRow"]').length >= 2);
    if (!sec) return { err: 'no groupSection with rows' };
    const rows = [...sec.querySelectorAll('[class*="sessionRow"]')];
    const tb = document.querySelector('[class*="treeBody"]');
    const before = {
      sidebarTextLen: (document.querySelector('[class*="sidebarCol"]') || document.querySelector('aside')).innerText.trim().length,
      treeBodyDisplay: getComputedStyle(tb).display,
      rows: rows.length,
    };
    // 前两行当作"要剔除的"
    rows.slice(0, 2).forEach((x) => x.setAttribute('data-wb-hide', '1'));
    void document.body.offsetHeight;
    const treeBodyNow = {
      display: getComputedStyle(tb).display,
      height: Math.round(tb.getBoundingClientRect().height),
      groups: tb.querySelectorAll('[class*="projectRow"]').length,
    };
    const hiddenRows = document.querySelectorAll('[data-wb-hide="1"]').length;
    const sidebarTextLen = (document.querySelector('[class*="sidebarCol"]') || document.querySelector('aside')).innerText.trim().length;
    rows.slice(0, 2).forEach((x) => x.removeAttribute('data-wb-hide'));
    void document.body.offsetHeight;
    return {
      before,
      treeBodyNow,
      hiddenRows,
      sidebarTextLen,
      // 关键结论：会话树还在、分组还在
      树还在: treeBodyNow.display !== 'none',
      分组数: treeBodyNow.groups,
    };
  });

  console.log(JSON.stringify({ hasRuleRemoved: ruleCount === 0, ruleCount, ...r, errs }, null, 1));
  await b.close();
})().catch((e) => { console.error('FAILED', e.stack.slice(0, 300)); process.exit(1); });
