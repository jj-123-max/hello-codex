const puppeteer = require('puppeteer-core');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const b = await puppeteer.launch({
    executablePath: EDGE, headless: true, args: ['--no-sandbox'],
    defaultViewport: { width: 1440, height: 900 },
  });
  const p = await b.newPage();
  await p.goto('http://127.0.0.1:4080/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await sleep(14000);

  const r = await p.evaluate(() => {
    // 找一个当前展开分组里的真实会话行，模拟剔除逻辑打标记
    const row = document.querySelector('[class*="sessionRow"]');
    if (!row) return { err: 'no sessionRow visible' };
    const before = {
      sidebarText: (() => {
        const el = document.querySelector('[class*="sidebarCol"]') || document.querySelector('aside');
        return (el.innerText || '').trim().length;
      })(),
      rowRect: row.getBoundingClientRect().height,
    };
    row.setAttribute('data-wb-hide', '1');
    // 强制重排，等样式生效
    void document.body.offsetHeight;
    const hits = [];
    document.querySelectorAll('[class*="list"]').forEach((l) => {
      [...l.children].forEach((c) => {
        if (c.querySelector && c.querySelector('[data-wb-hide="1"]')) {
          const k = c.getBoundingClientRect();
          hits.push({
            sel: c.tagName.toLowerCase() + '.' + String(c.className || '').split(/\s+/).slice(0, 3).join('.'),
            子元素数: c.children.length,
            display: getComputedStyle(c).display,
            高度: Math.round(k.height),
            含会话行: c.querySelectorAll('[class*="sessionRow"]').length,
            含分组: c.querySelectorAll('[class*="projectRow"]').length,
          });
        }
      });
    });
    const after = {
      sidebarText: (() => {
        const el = document.querySelector('[class*="sidebarCol"]') || document.querySelector('aside');
        return (el.innerText || '').trim().length;
      })(),
      sidebarDisplay: (() => {
        const el = document.querySelector('[class*="sidebarCol"]') || document.querySelector('aside');
        return getComputedStyle(el).display + '/' + Math.round(el.getBoundingClientRect().height);
      })(),
    };
    row.removeAttribute('data-wb-hide');
    return { before, hits, after };
  });

  console.log(JSON.stringify(r, null, 1));
  await b.close();
})().catch((e) => { console.error('FAILED', e.stack.slice(0, 300)); process.exit(1); });
