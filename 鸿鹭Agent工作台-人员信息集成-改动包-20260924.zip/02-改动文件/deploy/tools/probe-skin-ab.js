const path=require('path');const puppeteer=require('puppeteer-core');
const EDGE='C://Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const OUT=path.join(__dirname,'..','..','probe');
const sleep=(ms)=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({executablePath:EDGE,headless:true,args:['--no-sandbox'],defaultViewport:{width:1440,height:900}});
const p=await b.newPage();const errs=[];
p.on('pageerror',e=>errs.push(String(e).slice(0,110)));
await p.goto('http://127.0.0.1:4080/',{waitUntil:'domcontentloaded',timeout:60000});await sleep(13000);
await p.evaluate(()=>{const t=document.querySelector('textarea');if(!t)return;t.focus();Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(t,'你好，介绍一下这个工作台');t.dispatchEvent(new Event('input',{bubbles:true}));});
await sleep(1000);await p.keyboard.press('Enter');await sleep(12000);
for(const h of await p.$$('.wb-entry')){const t=await p.evaluate(e=>e.innerText||'',h);if(t&&/人员/.test(t)){await h.click();break;}}
await sleep(3500);
const probe=async()=>p.evaluate(()=>{
  const col=document.querySelector('[class*="centerCol"]');
  const q=s=>col.querySelector(s);
  const cs=(el,props)=>{if(!el)return null;const s=getComputedStyle(el);const o={};props.forEach(k=>o[k]=s[k]);return o};
  // 记录当前真实 class（抽样 lead 元素）
  const sb=col.querySelector('[class*="scrollBody"]');
  const chain=[];
  if(sb){let x=sb.querySelector('[class*="flowItem"]')||sb; let n=0;(function w(el,d){if(n>26||d>7)return;const c=String(el.getAttribute&&el.getAttribute('class')||'').split(/\s+/).filter(Boolean).slice(0,2);const t=el.childElementCount===0?(el.textContent||'').trim().slice(0,12):'';chain.push('  '.repeat(d)+el.tagName.toLowerCase()+(c.length?'.'+c.join('.'):'')+(t?' «'+t+'»':''));n++;[...el.children].forEach(k=>w(k,d+1))})(x,0);}
  return {
    split:document.documentElement.hasAttribute('data-dsh-wb-split'),
    styleTagOn: (()=>{const s=document.querySelector('style[data-wb-style="1"]');return s?!s.disabled:null})(),
    bubble:cs(q('[class*="bubble"]'),['borderRadius','backgroundColor','padding','maxWidth']),
    aiBody:cs(q('[class*="Sxvs8a_body"]'),['borderLeftWidth','borderLeftColor','paddingLeft']),
    tool:cs(q('[class*="osXY9a_root"]'),['borderRadius','backgroundColor']),
    card:cs(q('[class*="uV2eYG_card"]'),['borderRadius','borderTopColor']),
    send:cs(q('button[class*="uV2eYG_primary"]'),['borderRadius','backgroundColor']),
    chain:chain
  };
});
const on=await probe();
await p.screenshot({path:path.join(OUT,'70-skin-on.png')});
// 关掉我们的样式表 → 无皮肤对照
await p.evaluate(()=>{const s=document.querySelector('style[data-wb-style="1"]');if(s)s.disabled=true;});
await sleep(700);
const off=await probe();
await p.screenshot({path:path.join(OUT,'71-skin-off.png')});
console.log(JSON.stringify({ON:on,OFF:off,errs},null,2));
await b.close();})().catch(e=>{console.error('FAILED',e.stack.slice(0,400));process.exit(1)});
