const path = require('path');
const puppeteer = require('puppeteer-core');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const OUT = path.join(__dirname, '..', '..', 'probe');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const b = await puppeteer.launch({
    executablePath: EDGE,
    headless: true,
    args: ['--no-sandbox'],
    defaultViewport: { width: 1440, height: 900 },
  });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', (e) => errs.push(String(e).slice(0, 130)));

  await p.goto('http://127.0.0.1:4080/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await sleep(14000);

  // 发一条人员相关消息（手动模式下应浮出同步按钮）
  await p.evaluate(() => {
    const t = document.querySelector('[class*="centerCol"] textarea');
    if (!t) return;
    t.focus();
    Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set.call(t, '按部门统计人数');
    t.dispatchEvent(new Event('input', { bubbles: true }));
  });
  await sleep(1000);
  await p.keyboard.press('Enter');
  await sleep(16000);

  // 真实鼠标点「人员信息」
  const entries = await p.$$('.wb-entry');
  for (const h of entries) {
    const t = await p.evaluate((e) => e.innerText || '', h);
    if (t && /人员/.test(t)) { await h.click({ delay: 20 }); break; }
  }
  await sleep(5000);

  const r = await p.evaluate(() => {
    const cb = document.querySelector('.wb-cb');
    const anyStateBar = [...document.querySelectorAll('body *')].filter(
      (n) => !n.childElementCount && /已加载\s*\d+\s*条数据|自动同步/.test(n.textContent || '')
    ).length;
    const sb = document.querySelector('.wb-syncbtn');
    const panel = document.querySelector('[data-dsh-wb-view]');
    const col = document.querySelector('[class*="centerCol"]');
    return {
      stateBarExists: !!cb,
      autoSyncTextNodes: anyStateBar,
      split: document.documentElement.hasAttribute('data-dsh-wb-split'),
      panelW: panel ? Math.round(panel.getBoundingClientRect().width) : null,
      colW: col ? Math.round(col.getBoundingClientRect().width) : null,
      syncBtn: sb ? { show: sb.getAttribute('data-show'), txt: sb.innerText.replace(/\n/g, ' '), vis: getComputedStyle(sb).display } : null,
      panelTitle: document.querySelector('.wb-card__title span') ? document.querySelector('.wb-card__title span').innerText : null,
    };
  });
  await p.screenshot({ path: path.join(OUT, 'F0-nobar.png') });

  // 点同步按钮 → 左侧应渲染
  await p.evaluate(() => { const x = document.querySelector('.wb-syncbtn'); if (x) x.click(); });
  await sleep(1800);
  const after = await p.evaluate(() => ({
    stats: document.querySelectorAll('.wb-stat').length,
    trail: document.querySelector('.wb-trail__hd') ? document.querySelector('.wb-trail__hd').innerText.replace(/\n/g, ' ') : null,
    btn: (() => { const x = document.querySelector('.wb-syncbtn'); return x ? x.getAttribute('data-done') : null; })(),
  }));
  await p.screenshot({ path: path.join(OUT, 'F1-nobar-synced.png') });

  console.log(JSON.stringify({ ...r, after, errs }, null, 1));
  await b.close();
})().catch((e) => { console.error('FAILED', e.stack.slice(0, 400)); process.exit(1); });
