/**
 * 直接调 dsh web 的 RPC 接口（/api/<method>，body 为 client-request 信封）。
 * 用法： node deploy/tools/rpc.js <method> [jsonPayload]
 * 例：   node deploy/tools/rpc.js llm.models {}
 *       node deploy/tools/rpc.js session.create {"cwd":"C:\\Users\\74718\\WorkBuddy\\demo-9-7\\dsh-base"}
 */
const http = require('http');

const method = process.argv[2];
let payload = {};
if (process.argv[3]) {
  try { payload = JSON.parse(process.argv[3]); } catch (e) { console.error('bad payload json:', e.message); process.exit(1); }
}
const body = JSON.stringify({ type: 'client-request', rpcId: 'cli-' + Date.now(), method, payload });

const req = http.request({ host: '127.0.0.1', port: 4080, path: '/api/' + method, method: 'POST', headers: { 'content-type': 'application/json', 'content-length': Buffer.byteLength(body) } }, (res) => {
  let data = '';
  res.on('data', (c) => (data += c));
  res.on('end', () => {
    let out = data;
    try { out = JSON.stringify(JSON.parse(data), null, 2); } catch (e) {}
    console.log(out.length > 3000 ? out.slice(0, 3000) + '\n...(truncated)' : out);
  });
});
req.on('error', (e) => console.error('ERR', e.message));
req.write(body);
req.end();
