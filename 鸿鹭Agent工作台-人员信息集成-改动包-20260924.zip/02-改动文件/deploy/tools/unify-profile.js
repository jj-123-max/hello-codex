// 把 web profile 里的 @deepseek-ai 包统一到 core 的版本（rc.7）。
// 背景：web 侧 140 个包里有 66 个是 rc.8、64 个 rc.7，core 全是 rc.7。
// 混装造成一连串契约错位：
//   1) dsh-scope 的 kScope = Symbol("dsh.scope") 双实例 → agent 拿不到 scope key
//   2) dsh-host-apiproxy(rc.8) 要求 history 带 maxImageDimension → 历史加载失败
// 做法：版本不一致的包，原地改名备份到 _rc8bak/，再建 junction 指向 core（同一份代码 = 单一实例）。
// 回滚：把 _rc8bak/<name> 改回原名、删掉 junction 即可（rollback-profile.js）。
const fs = require('fs');
const path = require('path');

const CORE = 'C:\\Users\\74718\\.dsh\\profiles\\node_modules\\@deepseek-ai';
const WEB = 'C:\\Users\\74718\\.dsh\\profiles\\web\\node_modules\\@deepseek-ai';
const BAK = path.join(WEB, '_rc8bak');

const ver = (p) => {
  try {
    return JSON.parse(fs.readFileSync(path.join(p, 'package.json'), 'utf8')).version;
  } catch (e) {
    return null;
  }
};

fs.mkdirSync(BAK, { recursive: true });

const done = [];
const skipped = [];
const noCore = [];

for (const name of fs.readdirSync(WEB)) {
  if (name.startsWith('_') || name.indexOf('_tmp_') >= 0 || name.endsWith('.bak')) continue;
  const w = path.join(WEB, name);
  const c = path.join(CORE, name);
  if (!fs.existsSync(c)) {
    noCore.push(name);
    continue;
  }
  let st;
  try {
    st = fs.lstatSync(w);
  } catch (e) {
    continue;
  }
  if (st.isSymbolicLink()) {
    skipped.push(name + ' (已是链接)');
    continue;
  }
  const wv = ver(w);
  const cv = ver(c);
  if (wv === cv) {
    skipped.push(name + ' (版本一致)');
    continue;
  }
  const bakp = path.join(BAK, name);
  if (fs.existsSync(bakp)) fs.rmSync(bakp, { recursive: true, force: true });
  fs.renameSync(w, bakp);
  fs.symlinkSync(c, w, 'junction');
  done.push(name + ': ' + wv + ' -> ' + cv);
}

console.log('统一到 core 的包数: ' + done.length);
console.log('跳过: ' + skipped.length + '   core 无对应: ' + noCore.length + (noCore.length ? ' [' + noCore.join(', ') + ']' : ''));
console.log('--- 已替换 ---');
console.log(done.join('\n'));
