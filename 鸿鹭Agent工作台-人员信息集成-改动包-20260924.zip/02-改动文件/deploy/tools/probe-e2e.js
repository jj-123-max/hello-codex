const path = require('path');
const puppeteer = require('puppeteer-core');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const OUT = path.join(__dirname, '..', '..', 'probe');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const snap = (p, label) =>
  p.evaluate((lb) => {
    const q = (s) => document.querySelector(s);
    const rect = (el) => {
      if (!el) return null;
      const k = el.getBoundingClientRect();
      return { x: Math.round(k.x), y: Math.round(k.y), w: Math.round(k.width), h: Math.round(k.height) };
    };
    const hist = q('.wb-hist');
    const center = hist && hist.getAttribute('data-show') === '1' ? rect(hist) : null;
    let hit = null;
    if (center) {
      const el = document.elementFromPoint(center.x + center.w / 2, center.y + 20);
      hit = el ? el.tagName.toLowerCase() + '.' + String(el.getAttribute('class') || '').split(/\s+/).slice(0, 2).join('.') : 'none';
    }
    const panel = q('[data-dsh-wb-view]');
    const ptitle = panel ? (panel.querySelector('.wb-panel-title') || {}).textContent : null;
    return {
      label: lb,
      split: document.documentElement.hasAttribute('data-dsh-wb-split'),
      panelExists: !!panel,
      panelRect: rect(panel),
      panelTitle: ptitle || null,
      histShow: hist ? hist.getAttribute('data-show') : null,
      histRect: rect(hist),
      histItems: document.querySelectorAll('.wb-hist__item').length,
      histHitAtCenter: hit,
      newBtnShow: (() => { const b = q('.wb-newchat'); return b ? b.getAttribute('data-show') : null; })(),
      histBtnShow: (() => { const b = q('.wb-histbtn'); return b ? b.getAttribute('data-show') : null; })(),
      biRoot: (() => { const b = q('[class*="centerCol"] [class*="bi-root"]'); return b ? getComputedStyle(b).display : '(missing)'; })(),
      uActions: (() => { const b = q('[class*="centerCol"] [class*="u_actions"]'); return b ? getComputedStyle(b).display : '(missing)'; })(),
    };
  }, label);

async function clickEl(p, sel) {
  const h = await p.$(sel);
  if (!h) return false;
  const box = await h.boundingBox();
  if (!box) return false;
  await p.mouse.click(Math.round(box.x + box.width / 2), Math.round(box.y + box.height / 2));
  return true;
}

(async () => {
  const b = await puppeteer.launch({ executablePath: EDGE, headless: true, args: ['--no-sandbox'], defaultViewport: { width: 1440, height: 900 } });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', (e) => errs.push(String(e).slice(0, 130)));
  await p.goto('http://127.0.0.1:4080/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await sleep(14000);
  // 发一条消息，制造"有 header"的会话
  await p.evaluate(() => {
    const t = document.querySelector('[class*="centerCol"] textarea');
    if (!t) return;
    t.focus();
    Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set.call(t, '你好');
    t.dispatchEvent(new Event('input', { bubbles: true }));
  });
  await sleep(1000);
  await p.keyboard.press('Enter');
  await sleep(13000);

  // 真实鼠标点侧栏「人员信息」
  const entries = await p.$$('.wb-entry');
  for (const h of entries) {
    const t = await p.evaluate((e) => e.innerText || '', h);
    if (t && /人员/.test(t)) { await h.click(); break; }
  }
  await sleep(4500);
  console.log('A 进面板:', JSON.stringify(await snap(p, 'A')));

  // 真实鼠标点「历史」
  await clickEl(p, '.wb-histbtn');
  await sleep(1600);
  console.log('B 点历史:', JSON.stringify(await snap(p, 'B')));
  await p.screenshot({ path: path.join(OUT, 'E0-hist-real.png') });

  // 点空白关闭
  await p.mouse.click(700, 700);
  await sleep(800);
  console.log('C 关历史:', JSON.stringify(await snap(p, 'C')));

  // 真实鼠标点「新建对话」
  await clickEl(p, '.wb-newchat');
  await sleep(8000);
  console.log('D 点新建对话:', JSON.stringify(await snap(p, 'D')));
  await p.screenshot({ path: path.join(OUT, 'E1-newchat-real.png') });

  // 真实鼠标点底座「新会话」
  await clickEl(p, '[class*="newSession"]');
  await sleep(8000);
  console.log('E 点底座新会话:', JSON.stringify(await snap(p, 'E')));
  await p.screenshot({ path: path.join(OUT, 'E2-native-new.png') });

  console.log('errs:', JSON.stringify(errs));
  await b.close();
})().catch((e) => {
  console.error('FAILED', e.stack.slice(0, 400));
  process.exit(1);
});
