const path=require('path');const puppeteer=require('puppeteer-core');
const EDGE='C://Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const OUT=path.join(__dirname,'..','..','probe');
const sleep=(ms)=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({executablePath:EDGE,headless:true,args:['--no-sandbox'],defaultViewport:{width:1440,height:900}});
const p=await b.newPage();const errs=[];
p.on('pageerror',e=>errs.push(String(e).slice(0,150)));
await p.goto('http://127.0.0.1:4080/',{waitUntil:'domcontentloaded',timeout:60000});await sleep(13000);
for(const h of await p.$$('.wb-entry')){const t=await p.evaluate(e=>e.innerText||'',h);if(t&&/人员/.test(t)){await h.click();break;}}
await sleep(3000);
// 模拟右侧会话里出现一条用户消息（真实场景：dsh 把它渲染出来）
const injected=await p.evaluate(()=>{
  const col=document.querySelector('[class*="centerCol"]');
  if(!col) return 'no col';
  const d=document.createElement('div');
  d.className='userMessage';d.style.padding='8px';
  d.textContent='帮我按工作地统计一下人数';
  col.appendChild(d);
  return 'ok';
});
await sleep(2500);
const res=await p.evaluate(()=>({
  trailHd:Array.from(document.querySelectorAll('.wb-trail__hd')).map(r=>(r.innerText||'').replace(/\n/g,' ')),
  steps:Array.from(document.querySelectorAll('.wb-trail__step')).map(r=>(r.innerText||'').replace(/\n/g,' ')),
  resHd:Array.from(document.querySelectorAll('.wb-res__hd')).map(r=>(r.innerText||'').replace(/\n/g,' ')),
  stats:Array.from(document.querySelectorAll('.wb-stat')).map(s=>((s.querySelector('.wb-stat__k')||{}).innerText)+'='+((s.querySelector('.wb-stat__v')||{}).innerText)),
  bars:Array.from(document.querySelectorAll('.wb-bar')).map(r=>(r.innerText||'').replace(/\n/g,' ')),
}));
await p.screenshot({path:path.join(OUT,'24-agent-bridge.png')});
console.log(JSON.stringify({injected,res,errs},null,2));
await b.close();})().catch(e=>{console.error('FAILED:',e.stack.slice(0,400));process.exit(1)});
