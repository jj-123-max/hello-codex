const path = require('path');
const puppeteer = require('puppeteer-core');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const OUT = path.join(__dirname, '..', '..', 'probe');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const b = await puppeteer.launch({ executablePath: EDGE, headless: true, args: ['--no-sandbox'], defaultViewport: { width: 1440, height: 900 } });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', (e) => errs.push(String(e).slice(0, 160)));
  p.on('console', (m) => { if (m.type() === 'error') errs.push('console: ' + String(m.text()).slice(0, 160)); });

  await p.goto('http://127.0.0.1:4080/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await sleep(13000);

  // 1) 点侧栏「人员信息」
  let opened = false;
  for (const h of await p.$$('.wb-entry')) {
    const t = await p.evaluate((e) => e.innerText || '', h);
    if (t && /人员/.test(t)) { await h.click(); opened = true; break; }
  }
  await sleep(3500);

  const s1 = await p.evaluate(() => {
    const view = document.querySelector('[data-dsh-wb-view]');
    const col = document.querySelector('[class*="centerCol"]');
    return {
      hasView: !!view,
      agentBox: !!document.querySelector('.wb-agent__box'),
      chips: Array.from(document.querySelectorAll('.wb-chip')).map((c) => c.innerText),
      viewW: view ? Math.round(view.getBoundingClientRect().width) : 0,
      colW: col ? Math.round(col.getBoundingClientRect().width) : 0,
      colScroll: col ? [col.clientWidth, col.scrollWidth] : null,
    };
  });
  await p.screenshot({ path: path.join(OUT, '20-agent-idle.png') });

  // 2) 点「按部门统计」
  let clickedChip = null;
  for (const c of await p.$$('.wb-chip')) {
    const t = await p.evaluate((e) => e.innerText || '', c);
    if (/部门/.test(t)) { await c.click(); clickedChip = t; break; }
  }
  await sleep(1600);

  const s2 = await p.evaluate(() => {
    const stats = Array.from(document.querySelectorAll('.wb-stat')).map((s) => ({
      k: (s.querySelector('.wb-stat__k') || {}).innerText,
      v: (s.querySelector('.wb-stat__v') || {}).innerText,
    }));
    const bars = Array.from(document.querySelectorAll('.wb-bar')).map((r) => (r.innerText || '').replace(/\n/g, ' '));
    const trail = Array.from(document.querySelectorAll('.wb-trail__step')).map((r) => (r.innerText || '').replace(/\n/g, ' '));
    return { stats, bars, trail };
  });
  await p.screenshot({ path: path.join(OUT, '21-agent-stats.png') });

  // 3) 点「信息待补全」
  for (const c of await p.$$('.wb-chip')) {
    const t = await p.evaluate((e) => e.innerText || '', c);
    if (/补全/.test(t)) { await c.click(); break; }
  }
  await sleep(1600);
  const s3 = await p.evaluate(() => {
    const rows = Array.from(document.querySelectorAll('[data-dsh-wb-view] .wb-table tbody tr')).slice(0, 5).map((r) => (r.innerText || '').replace(/\t/g, ' | '));
    const hd = Array.from(document.querySelectorAll('.wb-res__hd')).map((r) => (r.innerText || '').replace(/\n/g, ' '));
    return { rows, hd };
  });
  await p.screenshot({ path: path.join(OUT, '22-agent-rows.png') });

  // 4) 右侧 dsh 原生会话是否仍可用（底座能力）
  const s4 = await p.evaluate(() => {
    const col = document.querySelector('[class*="centerCol"]');
    if (!col) return { err: 'no col' };
    const editable = col.querySelector('textarea, [contenteditable="true"], input[type="text"]');
    let typed = null;
    if (editable) {
      editable.focus();
      if (editable.tagName === 'TEXTAREA' || editable.tagName === 'INPUT') {
        editable.value = '按部门统计人数';
        editable.dispatchEvent(new Event('input', { bubbles: true }));
        typed = editable.value;
      } else {
        editable.textContent = '按部门统计人数';
        typed = editable.textContent;
      }
    }
    return {
      editableTag: editable ? editable.tagName + '.' + String(editable.className).slice(0, 24) : null,
      typed,
      colW: Math.round(col.getBoundingClientRect().width),
      colScrollOk: col.scrollWidth <= col.clientWidth + 4,
    };
  });
  await sleep(1800);
  const s5 = await p.evaluate(() => {
    const trail = Array.from(document.querySelectorAll('.wb-trail__hd')).map((r) => (r.innerText || '').replace(/\n/g, ' '));
    return { trailHd: trail };
  });
  await p.screenshot({ path: path.join(OUT, '23-agent-bridge.png') });

  console.log(JSON.stringify({ opened, clickedChip, s1, s2, s3, s4, s5, errs: errs.slice(0, 6) }, null, 2));
  await b.close();
})().catch((e) => {
  console.error('FAILED:', e.stack.slice(0, 500));
  process.exit(1);
});
