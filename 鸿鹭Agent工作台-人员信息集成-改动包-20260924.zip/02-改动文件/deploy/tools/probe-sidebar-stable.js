const path=require('path');const puppeteer=require('puppeteer-core');
const EDGE='C://Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const OUT=path.join(__dirname,'..','..','probe');
const sleep=(ms)=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({executablePath:EDGE,headless:true,args:['--no-sandbox'],defaultViewport:{width:1440,height:900}});
const p=await b.newPage();const errs=[];
p.on('pageerror',e=>errs.push(String(e).slice(0,140)));
await p.goto('http://127.0.0.1:4080/',{waitUntil:'domcontentloaded',timeout:60000});await sleep(15000);
const snap=()=>p.evaluate(()=>{
  const tb=document.querySelector('[class*="treeBody"]');
  const sb=document.querySelector('[class*="sidebarCol"]')||document.querySelector('aside');
  const biz=[...document.querySelectorAll('[class*="projectRow"]')].find(x=>x.getAttribute('data-wb-bizgrp')==='1');
  return {树显示:tb?getComputedStyle(tb).display:null, 树高:tb?Math.round(tb.getBoundingClientRect().height):null,
    分组数:tb?tb.querySelectorAll('[class*="projectRow"]').length:null,
    侧栏文本长度:(sb.innerText||'').trim().length,
    业务分组显示:biz?getComputedStyle(biz).display:null, 业务分组展开:biz?biz.getAttribute('aria-expanded'):null,
    被剔除行:document.querySelectorAll('[data-wb-hide="1"]').length,
    包裹标记:document.querySelectorAll('[data-wb-hidewrap="1"]').length,
    业务标签:(document.querySelector('.wb-biztag')||{}).innerText};
});
console.log('T+15s ', JSON.stringify(await snap()));
await sleep(12000);
console.log('T+27s ', JSON.stringify(await snap()));
await sleep(12000);
console.log('T+39s ', JSON.stringify(await snap()));
await p.screenshot({path:path.join(OUT,'G1-sidebar-ok.png')});
console.log('errs:',JSON.stringify(errs));
await b.close();})().catch(e=>{console.error('FAILED',e.stack.slice(0,300));process.exit(1)});
