const path=require('path'),fss=require('fs');const puppeteer=require('puppeteer-core');
const EDGE='C://Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const OUT=path.join(__dirname,'..','..','probe');
const sleep=(ms)=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({executablePath:EDGE,headless:true,args:['--no-sandbox'],defaultViewport:{width:1440,height:900}});
const p=await b.newPage();
await p.goto('http://127.0.0.1:4080/',{waitUntil:'domcontentloaded',timeout:60000});await sleep(14000);
const send=async(t)=>{await p.evaluate((v)=>{const el=document.querySelector('textarea');if(!el)return;el.focus();Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(el,v);el.dispatchEvent(new Event('input',{bubbles:true}));},t);await sleep(1000);await p.keyboard.press('Enter');};
await send('你好');await sleep(9000);
const dump=await p.evaluate(()=>{
  const col=document.querySelector('[class*="centerCol"]');
  const cls=(n)=>String((n.getAttribute&&n.getAttribute('class'))||'').split(/\s+/).filter(Boolean);
  const sb=col.querySelector('[class*="_scrollBody"]');
  const out=[];let n=0;
  (function w(x,d){ if(n>85||d>11)return; const t=x.childElementCount===0?(x.textContent||'').trim().slice(0,16):''; out.push('  '.repeat(d)+x.tagName.toLowerCase()+(cls(x).length?'.'+cls(x).join('.'):'')+(t?'  «'+t+'»':'')); n++; [...x.children].forEach(k=>w(k,d+1)); })(sb,0);
  return {text:(sb?sb.innerText:'').slice(0,220), tree:out};
});
fss.writeFileSync(path.join(OUT,'skin-dump4.json'),JSON.stringify(dump,null,2));
console.log('INNERTEXT:',dump.text.replace(/\n/g,' | '));
console.log('---TREE---');
console.log(dump.tree.join('\n'));
await p.screenshot({path:path.join(OUT,'33-skin-chat.png')});
await b.close();})().catch(e=>{console.error('FAILED:',e.stack.slice(0,300));process.exit(1)});
