#!/usr/bin/env node
/**
 * 零依赖 markdown → 单文件 HTML 转换器（够用就好）
 * 支持：标题 / 段落 / 引用 / 表格 / 围栏代码 / 有序无序列表（含一层缩进）/ 分隔线 / 行内 粗体·代码·链接
 * 用法：node md2html.js <input.md> <output.html> ["页面标题"]
 */
const fs = require('fs');
const path = require('path');

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

function inline(s) {
  let t = esc(s);
  t = t.replace(/`([^`]+)`/g, (m, c) => '<code>' + c + '</code>');
  t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  t = t.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
  return t;
}

function convert(md) {
  const lines = md.replace(/\r\n/g, '\n').split('\n');
  const out = [];
  let i = 0;
  let listBuf = null; // { tag, items: [ {text, sub:[...]} ] }

  const flushList = () => {
    if (!listBuf) return;
    out.push('<' + listBuf.tag + '>' + listBuf.items.map((it) => {
      const sub = it.sub && it.sub.length ? '<ul>' + it.sub.map((x) => '<li>' + x + '</li>').join('') + '</ul>' : '';
      return '<li>' + it.text + sub + '</li>';
    }).join('') + '</' + listBuf.tag + '>');
    listBuf = null;
  };

  while (i < lines.length) {
    const raw = lines[i];
    const line = raw.replace(/\s+$/, '');

    // 围栏代码
    if (/^```/.test(line)) {
      flushList();
      const buf = [];
      i++;
      while (i < lines.length && !/^```/.test(lines[i])) { buf.push(lines[i]); i++; }
      i++; // 跳过结束围栏
      out.push('<pre><code>' + esc(buf.join('\n')) + '</code></pre>');
      continue;
    }

    // 分隔线
    if (/^(-{3,}|\*{3,})$/.test(line.trim())) {
      flushList();
      out.push('<hr>');
      i++;
      continue;
    }

    // 标题
    const h = line.match(/^(#{1,6})\s+(.*)$/);
    if (h) {
      flushList();
      const lv = h[1].length;
      const id = 'h' + lv + '-' + Math.random().toString(36).slice(2, 7);
      out.push('<h' + lv + ' id="' + id + '">' + inline(h[2]) + '</h' + lv + '>');
      i++;
      continue;
    }

    // 表格（当前行有 | 且下一行是分隔行）
    if (line.indexOf('|') >= 0 && i + 1 < lines.length && /^\s*\|?[\s:|-]+\|[\s:|-]*$/.test(lines[i + 1])) {
      flushList();
      const cells = (s) => s.replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').map((x) => x.trim());
      const head = cells(line);
      i += 2;
      const body = [];
      while (i < lines.length && lines[i].indexOf('|') >= 0 && lines[i].trim() !== '') {
        body.push(cells(lines[i]));
        i++;
      }
      out.push(
        '<table><thead><tr>' + head.map((c) => '<th>' + inline(c) + '</th>').join('') + '</tr></thead><tbody>' +
        body.map((r) => '<tr>' + r.map((c) => '<td>' + inline(c) + '</td>').join('') + '</tr>').join('') +
        '</tbody></table>'
      );
      continue;
    }

    // 引用
    if (/^>\s?/.test(line)) {
      flushList();
      const buf = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) { buf.push(lines[i].replace(/^>\s?/, '')); i++; }
      out.push('<blockquote>' + buf.map((x) => (x.trim() ? '<p>' + inline(x) + '</p>' : '')).join('') + '</blockquote>');
      continue;
    }

    // 列表
    const li = raw.match(/^(\s*)([-*]|\d+\.)\s+(.*)$/);
    if (li) {
      const indent = li[1].length;
      const ordered = /\d+\./.test(li[2]);
      const tag = ordered ? 'ol' : 'ul';
      if (!listBuf) listBuf = { tag: tag, items: [] };
      if (listBuf.tag !== tag) { flushList(); listBuf = { tag: tag, items: [] }; }
      if (indent >= 2 && listBuf.items.length) {
        const last = listBuf.items[listBuf.items.length - 1];
        (last.sub = last.sub || []).push(inline(li[3]));
      } else {
        listBuf.items.push({ text: inline(li[3]) });
      }
      i++;
      continue;
    }

    // 空行
    if (line.trim() === '') { flushList(); i++; continue; }

    // 段落
    flushList();
    const buf = [line];
    i++;
    while (i < lines.length && lines[i].trim() !== '' && !/^(#{1,6}\s|>\s?|```|\s*([-*]|\d+\.)\s)/.test(lines[i]) && lines[i].indexOf('|') < 0) {
      buf.push(lines[i]);
      i++;
    }
    out.push('<p>' + inline(buf.join(' ')) + '</p>');
  }
  flushList();
  return out.join('\n');
}

const CSS = `
:root{--fg:#1d2129;--fg2:#5b6472;--line:#e8eaef;--brand:#4f6ef7;--bg:#fff;--soft:#f7f8fb;--code:#f4f6fa}
*{box-sizing:border-box}
body{margin:0;background:var(--soft);color:var(--fg);
 font:15px/1.78 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",Segoe UI,sans-serif}
.wrap{max-width:960px;margin:0 auto;padding:40px 32px 80px;background:var(--bg);min-height:100vh;
 box-shadow:0 0 0 1px var(--line)}
h1{font-size:27px;line-height:1.4;margin:0 0 6px;letter-spacing:-.2px}
h2{font-size:20px;margin:38px 0 14px;padding-bottom:9px;border-bottom:1px solid var(--line)}
h3{font-size:16.5px;margin:26px 0 10px}
h4{font-size:15px;margin:20px 0 8px;color:var(--fg2)}
p{margin:11px 0}
a{color:var(--brand);text-decoration:none;border-bottom:1px solid rgba(79,110,247,.3)}
hr{border:0;border-top:1px solid var(--line);margin:34px 0}
blockquote{margin:16px 0;padding:11px 16px;background:#fbfcff;border-left:3px solid var(--brand);
 border-radius:0 8px 8px 0;color:var(--fg2)}
blockquote p{margin:5px 0}
code{font-family:ui-monospace,SFMono-Regular,Consolas,"Courier New",monospace;font-size:12.6px;
 background:var(--code);border:1px solid #e9edf4;border-radius:5px;padding:1.5px 5px;color:#3c4a63}
pre{background:#1e2130;border-radius:10px;padding:15px 17px;overflow:auto;margin:15px 0}
pre code{background:none;border:0;padding:0;color:#dfe6f5;font-size:12.6px;line-height:1.72}
table{width:100%;border-collapse:collapse;margin:15px 0;font-size:13.6px;display:block;overflow-x:auto}
th,td{border:1px solid var(--line);padding:8px 11px;text-align:left;vertical-align:top}
th{background:#f6f8fc;font-weight:600;white-space:nowrap}
tbody tr:nth-child(even){background:#fafbfd}
ul,ol{margin:11px 0;padding-left:23px}
li{margin:5px 0}
li>ul,li>ol{margin:5px 0}
strong{font-weight:600}
@media print{body{background:#fff}.wrap{box-shadow:none;max-width:none}}
`;

const [input, output, title] = process.argv.slice(2);
if (!input || !output) {
  console.error('用法: node md2html.js <input.md> <output.html> ["标题"]');
  process.exit(1);
}
const md = fs.readFileSync(input, 'utf8');
const body = convert(md);
const pageTitle = title || (md.match(/^#\s+(.*)$/m) || [, path.basename(input)])[1];
const html = `<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(pageTitle)}</title><style>${CSS}</style></head>
<body><div class="wrap">
${body}
</div></body></html>`;
fs.writeFileSync(output, html, 'utf8');
console.log('OK ->', output, '(' + Buffer.byteLength(html, 'utf8') + ' bytes)');
