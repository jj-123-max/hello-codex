// 业务专属工作区：确保 ~/.dsh/storages/workspace.json 里存在「鸿鹭业务」工作区，
// 并把指定的业务会话登记进去（这样 dsh 侧栏会出现独立的「鸿鹭业务」分组，与用户自己的工作区隔离）。
// 用法：node biz-workspace.js [sessionId ...]
const fs = require('fs');
const crypto = require('crypto');

const F = 'C:\\Users\\74718\\.dsh\\storages\\workspace.json';
const BIZ_PATH = 'C:\\Users\\74718\\WorkBuddy\\demo-9-7\\dsh-base\\biz-workspace';
const BIZ_TITLE = '鸿鹭业务';

function load() {
  return JSON.parse(fs.readFileSync(F, 'utf8'));
}

function ensure(j) {
  j.global = j.global || {};
  j.global.workspaceIds = j.global.workspaceIds || [];
  j.tables = j.tables || {};
  j.tables.workspaces = j.tables.workspaces || {};
  let id = Object.keys(j.tables.workspaces).find(function (k) {
    return j.tables.workspaces[k].path === BIZ_PATH;
  });
  if (!id) {
    id = crypto.randomUUID();
    j.tables.workspaces[id] = {
      path: BIZ_PATH,
      title: BIZ_TITLE,
      sessionIds: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    j.global.workspaceIds.push(id);
  }
  return id;
}

function save(j) {
  fs.writeFileSync(F, JSON.stringify(j, null, 2));
}

const ids = process.argv.slice(2).filter(Boolean);
const j = load();
fs.copyFileSync(F, F + '.wb-bak');
const wid = ensure(j);
const w = j.tables.workspaces[wid];
ids.forEach(function (s) {
  if (w.sessionIds.indexOf(s) < 0) w.sessionIds.push(s);
});
w.updatedAt = new Date().toISOString();
save(j);
console.log(JSON.stringify({ workspaceId: wid, title: w.title, path: w.path, sessions: w.sessionIds }, null, 2));
