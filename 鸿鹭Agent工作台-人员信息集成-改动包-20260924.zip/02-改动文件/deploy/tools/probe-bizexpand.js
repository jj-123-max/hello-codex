const path = require('path');
const puppeteer = require('puppeteer-core');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const OUT = path.join(__dirname, '..', '..', 'probe');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const b = await puppeteer.launch({
    executablePath: EDGE, headless: true, args: ['--no-sandbox'],
    defaultViewport: { width: 1440, height: 900 },
  });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', (e) => errs.push(String(e).slice(0, 140)));
  await p.goto('http://127.0.0.1:4080/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await sleep(15000);

  const box = await p.evaluate(() => {
    const r = [...document.querySelectorAll('[class*="projectRow"]')].find((x) => x.getAttribute('data-wb-bizgrp') === '1');
    if (!r) return null;
    const k = r.getBoundingClientRect();
    return { left: Math.round(k.left), right: Math.round(k.right), top: Math.round(k.top), w: Math.round(k.width), h: Math.round(k.height) };
  });
  console.log('业务分组行 rect:', JSON.stringify(box));

  const expandedNow = () => p.evaluate(() =>
    (() => { const r = [...document.querySelectorAll('[class*="projectRow"]')].find((x) => x.getAttribute('data-wb-bizgrp') === '1'); return r ? r.getAttribute('aria-expanded') : null; })()
  );

  // 依次试几个点：左缘（caret）/ 标题 / 行中，每次用真实鼠标
  const tries = [
    { x: box.left + 12, y: box.top + box.h / 2, tag: 'caret 区' },
    { x: box.left + 60, y: box.top + box.h / 2, tag: '标题区' },
    { x: box.left + box.w / 2, y: box.top + box.h / 2, tag: '行中' },
  ];
  for (const t of tries) {
    await p.mouse.click(Math.round(t.x), Math.round(t.y), { delay: 40 });
    await sleep(2500);
    const e = await expandedNow();
    console.log(`点 ${t.tag} (${Math.round(t.x)},${Math.round(t.y)}) → aria-expanded=${e}`);
    if (e === 'true') break;
  }

  const r = await p.evaluate(() => {
    const tb = document.querySelector('[class*="treeBody"]');
    const sb = document.querySelector('[class*="sidebarCol"]') || document.querySelector('aside');
    const biz = [...document.querySelectorAll('[class*="projectRow"]')].find((x) => x.getAttribute('data-wb-bizgrp') === '1');
    const sec = biz ? biz.closest('[class*="groupSection"]') : null;
    return {
      树显示: tb ? getComputedStyle(tb).display : null,
      树高: tb ? Math.round(tb.getBoundingClientRect().height) : null,
      分组数: tb ? tb.querySelectorAll('[class*="projectRow"]').length : null,
      侧栏文本长度: (sb.innerText || '').trim().length,
      业务分组展开: biz ? biz.getAttribute('aria-expanded') : null,
      业务行数: sec ? sec.querySelectorAll('[class*="sessionRow"]').length : 0,
      被剔除行: document.querySelectorAll('[data-wb-hide="1"]').length,
      包裹标记: document.querySelectorAll('[data-wb-hidewrap="1"]').length,
      业务标签: (document.querySelector('.wb-biztag') || {}).innerText,
      可见行标题: sec ? [...sec.querySelectorAll('[class*="sessionRow"]')].map((x) => {
        const t = x.querySelector('[class*="title"]');
        const k = x.getBoundingClientRect();
        return { t: t ? t.textContent.trim().slice(0, 18) : '', h: Math.round(k.height) };
      }) : [],
    };
  });
  console.log(JSON.stringify(r, null, 1));
  await p.screenshot({ path: path.join(OUT, 'G2-biz-expanded.png') });
  console.log('errs:', JSON.stringify(errs));
  await b.close();
})().catch((e) => { console.error('FAILED', e.stack.slice(0, 300)); process.exit(1); });
