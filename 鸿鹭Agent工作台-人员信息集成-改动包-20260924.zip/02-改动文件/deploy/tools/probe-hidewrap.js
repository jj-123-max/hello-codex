const puppeteer = require('puppeteer-core');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const b = await puppeteer.launch({
    executablePath: EDGE, headless: true, args: ['--no-sandbox'],
    defaultViewport: { width: 1440, height: 900 },
  });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', (e) => errs.push(String(e).slice(0, 140)));
  await p.goto('http://127.0.0.1:4080/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await sleep(15000);

  // 进人员信息，确保同步在跑
  for (const h of await p.$$('.wb-entry')) {
    const t = await p.evaluate((e) => e.innerText || '', h);
    if (t && /人员/.test(t)) { await h.click({ delay: 20 }); break; }
  }
  await sleep(5000);

  const r = await p.evaluate(async () => {
    const bizRow = [...document.querySelectorAll('[class*="projectRow"]')].find((x) => x.getAttribute('data-wb-bizgrp') === '1');
    if (!bizRow) return { err: 'no biz row' };
    const sec = bizRow.closest('[class*="groupSection"]');
    const tb = document.querySelector('[class*="treeBody"]');

    // 注入两条：一条「目录名」式（应被剔除），一条中文真实业务（应保留）
    const mk = (cls, title, id) => {
      const w = document.createElement('div');
      w.className = cls + '_wrap';
      w.setAttribute('data-inject', id);
      const row = document.createElement('div');
      row.className = cls + '_sessionRow';
      const t = document.createElement('span');
      t.className = cls + '_title';
      t.textContent = title;
      row.appendChild(t);
      w.appendChild(row);
      return w;
    };
    sec.appendChild(mk('zzt', 'dsh-base', 'junk'));
    sec.appendChild(mk('zzt', '按部门统计人数', 'biz'));

    const fire = () => { if (window.__wbChatSync) window.__wbChatSync(); };
    fire(); await new Promise((r) => setTimeout(r, 400)); fire();
    await new Promise((r) => setTimeout(r, 500));

    const junk = sec.querySelector('[data-inject="junk"]');
    const biz = sec.querySelector('[data-inject="biz"]');
    const out = {
      剔除行: junk.querySelector('[class*="sessionRow"]').getAttribute('data-wb-hide'),
      剔除行包裹: junk.getAttribute('data-wb-hidewrap'),
      保留行: biz.querySelector('[class*="sessionRow"]').getAttribute('data-wb-hide'),
      保留行包裹: biz.getAttribute('data-wb-hidewrap'),
      会话树显示: getComputedStyle(tb).display,
      分组数: tb.querySelectorAll('[class*="projectRow"]').length,
      分组行显示: getComputedStyle(bizRow).display,
      分组行仍带标记: bizRow.getAttribute('data-wb-bizgrp'),
      分组标签: (document.querySelector('.wb-biztag') || {}).innerText,
    };
    junk.remove();
    biz.remove();
    return out;
  });

  console.log(JSON.stringify({ ...r, errs }, null, 1));
  await b.close();
})().catch((e) => { console.error('FAILED', e.stack.slice(0, 300)); process.exit(1); });
