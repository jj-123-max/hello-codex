const path = require('path');
const puppeteer = require('puppeteer-core');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const OUT = path.join(__dirname, '..', '..', 'probe');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const SNAP = () => {
  const tb = document.querySelector('[class*="treeBody"]');
  const sb = document.querySelector('[class*="sidebarCol"]') || document.querySelector('aside');
  const biz = [...document.querySelectorAll('[class*="projectRow"]')].find((x) => x.getAttribute('data-wb-bizgrp') === '1');
  const sec = biz ? biz.closest('[class*="groupSection"]') : null;
  const rows = sec ? [...sec.querySelectorAll('[class*="sessionRow"]')] : [];
  return {
    展开: biz ? biz.getAttribute('aria-expanded') : null,
    行数: rows.length,
    可见行: rows.filter((x) => x.getBoundingClientRect().height > 0).length,
    树显示: tb ? getComputedStyle(tb).display : null,
    分组数: tb ? tb.querySelectorAll('[class*="projectRow"]').length : null,
    侧栏字数: (sb.innerText || '').trim().length,
  };
};

(async () => {
  const b = await puppeteer.launch({
    executablePath: EDGE, headless: true, args: ['--no-sandbox'],
    defaultViewport: { width: 1440, height: 900 },
  });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', (e) => errs.push(String(e).slice(0, 140)));
  await p.goto('http://127.0.0.1:4080/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await sleep(16000);

  const box = await p.evaluate(() => {
    const r = [...document.querySelectorAll('[class*="projectRow"]')].find((x) => x.getAttribute('data-wb-bizgrp') === '1');
    if (!r) return null;
    const k = r.getBoundingClientRect();
    return { x: Math.round(k.left + 60), y: Math.round(k.top + k.height / 2) };
  });
  console.log('点击坐标:', JSON.stringify(box));
  await p.mouse.click(box.x, box.y, { delay: 40 });
  console.log('点开后 →', JSON.stringify(await p.evaluate(SNAP)));

  for (let i = 1; i <= 8; i++) {
    await sleep(1000);
    console.log(`T+${i}s`, JSON.stringify(await p.evaluate(SNAP)));
  }
  await p.screenshot({ path: path.join(OUT, 'G3-biz-stays-open.png') });
  console.log('errs:', JSON.stringify(errs));
  await b.close();
})().catch((e) => { console.error('FAILED', e.stack.slice(0, 300)); process.exit(1); });
