// 修复 dsh 的 "unscoped context"：让 web profile 与 core 共用同一份 dsh-scope 模块实例。
// 原因：dsh-scope 里 `const kScope = Symbol("dsh.scope")` 用的是 Symbol() 而非 Symbol.for()，
// 两份副本会各自生成不同的 symbol → 一边写标记、另一边读不到 → agent 拿不到 scope key。
// 做法：把 web 侧的 dsh-scope 换成指向 core 的 junction（同一真实路径 = 同一模块实例）。
const fs = require('fs');
const path = require('path');

const CORE = 'C:\\Users\\74718\\.dsh\\profiles\\node_modules\\@deepseek-ai\\dsh-scope';
const WEB = 'C:\\Users\\74718\\.dsh\\profiles\\web\\node_modules\\@deepseek-ai\\dsh-scope';
const BAK = WEB + '.rc8.bak';
const log = [];

function stamp(p) {
  try {
    return JSON.parse(fs.readFileSync(path.join(p, 'package.json'), 'utf8')).version;
  } catch (e) {
    return 'n/a';
  }
}

if (!fs.existsSync(CORE)) {
  console.log('ABORT: core dsh-scope not found at ' + CORE);
  process.exit(1);
}

let st = null;
try {
  st = fs.lstatSync(WEB);
} catch (e) {
  st = null;
}

if (st && st.isSymbolicLink()) {
  log.push('web dsh-scope 已经是链接（跳过）: -> ' + fs.readlinkSync(WEB));
} else if (st && st.isDirectory()) {
  if (fs.existsSync(BAK)) {
    fs.rmSync(BAK, { recursive: true, force: true });
    log.push('清理旧备份 ' + BAK);
  }
  fs.renameSync(WEB, BAK);
  log.push('已备份 rc.8 目录 -> ' + BAK + ' (v' + stamp(BAK) + ')');
  fs.symlinkSync(CORE, WEB, 'junction');
  log.push('已建立 junction: ' + WEB + ' -> ' + CORE);
} else {
  fs.symlinkSync(CORE, WEB, 'junction');
  log.push('目标缺失，直接建立 junction -> ' + CORE);
}

const now = fs.lstatSync(WEB);
log.push('现在 web 侧: isSymlink=' + now.isSymbolicLink() + ' -> ' + (now.isSymbolicLink() ? fs.readlinkSync(WEB) : 'DIR'));
log.push('core 版本 = v' + stamp(CORE));
log.push('web 解析到 = ' + require.resolve('@deepseek-ai/dsh-scope', { paths: [path.dirname(WEB)] }));
console.log(log.join('\n'));
