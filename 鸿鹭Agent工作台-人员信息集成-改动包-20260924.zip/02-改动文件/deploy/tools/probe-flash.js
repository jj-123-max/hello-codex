const path = require('path');
const puppeteer = require('puppeteer-core');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const OUT = path.join(__dirname, '..', '..', 'probe');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const COUNT = () => {
  const biz = [...document.querySelectorAll('[class*="projectRow"]')].find((x) => x.getAttribute('data-wb-bizgrp') === '1');
  const sec = biz ? biz.closest('[class*="groupSection"]') : null;
  const rows = sec ? [...sec.querySelectorAll('[class*="sessionRow"]')] : [];
  const tb = document.querySelector('[class*="treeBody"]');
  return {
    exp: biz ? biz.getAttribute('aria-expanded') : null,
    rows: rows.length,
    vis: rows.filter((x) => x.getBoundingClientRect().height > 0).length,
    tree: tb ? getComputedStyle(tb).display : null,
    groups: tb ? tb.querySelectorAll('[class*="projectRow"]').length : null,
  };
};

(async () => {
  const b = await puppeteer.launch({
    executablePath: EDGE, headless: true, args: ['--no-sandbox'],
    defaultViewport: { width: 1440, height: 900 },
  });
  const p = await b.newPage();
  const errs = [];
  p.on('pageerror', (e) => errs.push(String(e).slice(0, 140)));
  await p.goto('http://127.0.0.1:4080/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await sleep(16000);

  const box = await p.evaluate(() => {
    const r = [...document.querySelectorAll('[class*="projectRow"]')].find((x) => x.getAttribute('data-wb-bizgrp') === '1');
    if (!r) return null;
    const k = r.getBoundingClientRect();
    return { x: Math.round(k.left + 60), y: Math.round(k.top + k.height / 2) };
  });
  await p.mouse.click(box.x, box.y, { delay: 30 });

  // 高频采样：看历史遗留会话行有没有"先露一下再消失"
  const samples = [];
  for (let i = 0; i < 14; i++) {
    samples.push(`+${i * 90}ms ${JSON.stringify(await p.evaluate(COUNT))}`);
    await sleep(90);
  }
  console.log(samples.join('\n'));

  await sleep(3000);
  console.log('3s 后 ', JSON.stringify(await p.evaluate(COUNT)));
  await sleep(5000);
  console.log('8s 后 ', JSON.stringify(await p.evaluate(COUNT)));
  await p.screenshot({ path: path.join(OUT, 'G4-no-flash.png') });
  console.log('errs:', JSON.stringify(errs));
  await b.close();
})().catch((e) => { console.error('FAILED', e.stack.slice(0, 300)); process.exit(1); });
