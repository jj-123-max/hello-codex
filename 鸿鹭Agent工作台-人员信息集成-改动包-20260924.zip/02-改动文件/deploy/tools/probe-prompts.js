const path=require('path');const puppeteer=require('puppeteer-core');
const EDGE='C://Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const OUT=path.join(__dirname,'..','..','probe');
const sleep=(ms)=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({executablePath:EDGE,headless:true,args:['--no-sandbox'],defaultViewport:{width:1440,height:900}});
const p=await b.newPage();const errs=[];
p.on('pageerror',e=>errs.push(String(e).slice(0,120)));
await p.goto('http://127.0.0.1:4080/',{waitUntil:'domcontentloaded',timeout:60000});await sleep(13000);
// 进分栏
for(const h of await p.$$('.wb-entry')){const t=await p.evaluate(e=>e.innerText||'',h);if(t&&/人员/.test(t)){await h.click();break;}}
await sleep(4000);
const s1=await p.evaluate(()=>{
  const el=document.getElementById('dsh-wb-prompts')||document.querySelector('.wb-pb');
  if(!el) return {found:false};
  const seat=document.querySelector('[class*="composerSeat"]');
  const r=el.getBoundingClientRect();const sr=seat.getBoundingClientRect();
  return {found:true,open:el.getAttribute('data-open'),vis:getComputedStyle(el).display,
    rect:{x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)},
    seatTop:Math.round(sr.top),seatLeft:Math.round(sr.left),seatW:Math.round(sr.width),
    tg:(el.querySelector('.wb-pb__tg')||{}).innerText};
});
await p.screenshot({path:path.join(OUT,'60-pb-closed.png')});
// 点开抽屉
await p.evaluate(()=>{document.querySelector('.wb-pb__tg').click();});
await sleep(900);
const s2=await p.evaluate(()=>{
  const el=document.querySelector('.wb-pb');
  const pills=[...el.querySelectorAll('.wb-pb__pill')].map(x=>x.innerText);
  const groups=[...el.querySelectorAll('.wb-pb__grp')].map(g=>g.innerText.replace(/\n/g,'/').slice(0,50));
  return {open:el.getAttribute('data-open'),count:pills.length,pills:pills.slice(0,6),groups:groups.length,hd:(el.querySelector('.wb-pb__hd')||{}).innerText};
});
await p.screenshot({path:path.join(OUT,'61-pb-open.png')});
// 键盘 ↓ 两次后回车填入
await p.keyboard.press('ArrowDown');await sleep(300);await p.keyboard.press('ArrowDown');await sleep(300);
await p.keyboard.press('Enter');await sleep(900);
const s3=await p.evaluate(()=>({
  open:document.querySelector('.wb-pb').getAttribute('data-open'),
  nativeValue:(document.querySelector('[class*="centerCol"] textarea')||{}).value,
  focused:document.activeElement && document.activeElement.tagName,
}));
await p.screenshot({path:path.join(OUT,'62-pb-filled.png')});
// 再测：点「换一批」+ 点某个气泡
await p.keyboard.down('Control');await p.keyboard.press('k');await p.keyboard.up('Control');await sleep(700);
const s4a=await p.evaluate(()=>document.querySelector('.wb-pb').getAttribute('data-open'));
await p.evaluate(()=>{document.querySelector('.wb-pb__rand').click();});await sleep(500);
const s4b=await p.evaluate(()=>[...document.querySelectorAll('.wb-pb__pill')].slice(0,3).map(x=>x.innerText));
await p.evaluate(()=>{document.querySelectorAll('.wb-pb__pill')[1].click();});await sleep(800);
const s4=await p.evaluate(()=>({open:document.querySelector('.wb-pb').getAttribute('data-open'),nativeValue:(document.querySelector('[class*="centerCol"] textarea')||{}).value}));
await p.screenshot({path:path.join(OUT,'63-pb-picked.png')});
console.log(JSON.stringify({s1,s2,s3,ctrlK: s4a, afterRand:s4b, s4, errs},null,2));
await b.close();})().catch(e=>{console.error('FAILED',e.stack.slice(0,400));process.exit(1)});
