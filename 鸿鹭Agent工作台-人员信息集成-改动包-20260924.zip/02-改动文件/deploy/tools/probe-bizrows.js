const puppeteer = require('puppeteer-core');
const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const b = await puppeteer.launch({
    executablePath: EDGE, headless: true, args: ['--no-sandbox'],
    defaultViewport: { width: 1440, height: 900 },
  });
  const p = await b.newPage();
  await p.goto('http://127.0.0.1:4080/', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await sleep(15000);

  // 点开业务分组（真实鼠标）
  const box = await p.evaluate(() => {
    const r = [...document.querySelectorAll('[class*="projectRow"]')].find((x) => x.getAttribute('data-wb-bizgrp') === '1');
    if (!r) return null;
    const k = r.getBoundingClientRect();
    return { x: Math.round(k.left + 60), y: Math.round(k.top + k.height / 2) };
  });
  if (box) await p.mouse.click(box.x, box.y, { delay: 30 });
  await sleep(3000);

  const r = await p.evaluate(() => {
    const biz = [...document.querySelectorAll('[class*="projectRow"]')].find((x) => x.getAttribute('data-wb-bizgrp') === '1');
    const sec = biz ? biz.closest('[class*="groupSection"]') : null;
    const rows = sec ? [...sec.querySelectorAll('[class*="sessionRow"]')] : [];
    return {
      分组原生标题: (() => { const t = biz && biz.querySelector('[class*="title"]'); return t ? t.textContent : null; })(),
      行: rows.map((x) => {
        const t = x.querySelector('[class*="title"]');
        const attrs = {};
        for (const a of x.attributes) if (a.name !== 'class') attrs[a.name] = String(a.value).slice(0, 60);
        const sub = x.querySelector('[class*="sub"], [class*="meta"], [class*="time"]');
        return {
          标题: t ? t.textContent.trim() : (x.textContent || '').trim().slice(0, 30),
          副文本: sub ? sub.textContent.trim().slice(0, 24) : null,
          隐藏: x.getAttribute('data-wb-hide'),
          属性: attrs,
        };
      }),
    };
  });
  console.log(JSON.stringify(r, null, 1));
  await b.close();
})().catch((e) => { console.error('FAILED', e.stack.slice(0, 300)); process.exit(1); });
