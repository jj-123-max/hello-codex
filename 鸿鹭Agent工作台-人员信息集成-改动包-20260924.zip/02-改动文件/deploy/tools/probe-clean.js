const path=require('path');const puppeteer=require('puppeteer-core');
const EDGE='C://Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const OUT=path.join(__dirname,'..','..','probe');
const sleep=(ms)=>new Promise(r=>setTimeout(r,ms));
(async()=>{
const b=await puppeteer.launch({executablePath:EDGE,headless:true,args:['--no-sandbox'],defaultViewport:{width:1440,height:900}});
const p=await b.newPage();const errs=[];
p.on('pageerror',e=>errs.push(String(e).slice(0,120)));
await p.goto('http://127.0.0.1:4080/',{waitUntil:'domcontentloaded',timeout:60000});await sleep(14000);
await p.evaluate(()=>{const t=document.querySelector('[class*="centerCol"] textarea');if(!t)return;t.focus();Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(t,'你好');t.dispatchEvent(new Event('input',{bubbles:true}));});
await sleep(1000);await p.keyboard.press('Enter');await sleep(14000);
for(const h of await p.$$('.wb-entry')){const t=await p.evaluate(e=>e.innerText||'',h);if(t&&/人员/.test(t)){await h.click();break;}}
await sleep(4500);
const r=await p.evaluate(()=>{
  const col=document.querySelector('[class*="centerCol"]');
  const disp=s=>{const el=col.querySelector(s);return el?getComputedStyle(el).display:'(missing)'};
  const nb=document.querySelector('.wb-newchat'), hb=document.querySelector('.wb-histbtn'), sl=document.querySelector('.wb-slim');
  const rect=el=>el?(()=>{const k=el.getBoundingClientRect();return{x:Math.round(k.x),y:Math.round(k.y),w:Math.round(k.width)}})():null;
  return {
    hidden:{u_actions:disp('[class*="u_actions"]'),headerUtilities:disp('[class*="headerUtilities"]'),
      headerActions:disp('[class*="headerActions"]'),tabs:disp('[class*="wSkVaW_tabs"]'),biRoot:disp('[class*="bi-root"]')},
    newBtn:{show:nb?nb.getAttribute('data-show'):null,rect:rect(nb)},
    histBtn:{show:hb?hb.getAttribute('data-show'):null,rect:rect(hb),txt:hb?hb.innerText.trim():null},
    slim:sl?sl.innerText.replace(/\n/g,' '):null,
    visibleTexts:[...col.querySelectorAll('*')].filter(n=>!n.childElementCount&&(n.textContent||'').trim()&&n.offsetParent!==null).map(n=>n.textContent.trim()).slice(0,26)
  };
});
await p.screenshot({path:path.join(OUT,'C0-clean.png')});
// 打开历史
await p.evaluate(()=>{const b2=document.querySelector('.wb-histbtn');if(b2)b2.click();});
await sleep(1500);
const h=await p.evaluate(()=>{
  const w=document.querySelector('.wb-hist');
  const items=[...document.querySelectorAll('.wb-hist__item')].map(x=>x.innerText.replace(/\n/g,' / '));
  return {show:w?w.getAttribute('data-show'):null, count:items.length, items:items.slice(0,8)};
});
await p.screenshot({path:path.join(OUT,'C1-hist.png')});
console.log(JSON.stringify({...r,hist:h,errs},null,1));
await b.close();})().catch(e=>{console.error('FAILED',e.stack.slice(0,400));process.exit(1)});
