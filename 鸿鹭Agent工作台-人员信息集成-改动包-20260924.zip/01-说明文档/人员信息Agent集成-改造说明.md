# 鸿鹭 Agent 工作台 · 「人员信息 + Agent 对话」改造说明

> 版本：2026-09-24　适用工程：`demo-9-7/dsh-base`　形态：dsh web 控制台（4080）插件
> 本文说明**改造原理、涉及文件、代码逻辑**，以及踩过的坑与验证方法。

---

## 0. 一句话概括

在 dsh web（4080）里，**人员信息版块**由插件注入到侧栏与中心区；点开后**左侧是业务面板，右侧仍是 dsh 原生会话**（一行不改）；面板自带 Agent 能力（解析指令 → 调用人员数据工具 → 渲染成统计卡/分布条/风险表），并支持把右侧对话中的结果**手动同步**到左侧。

---

## 1. 目标与边界

**要做**

| 目标 | 落地方式 |
|---|---|
| 人员信息成为独立版块（左业务面板 / 右原生对话） | 插件注入侧栏入口 + 中心区面板，shell 包一层做左右分栏 |
| 保留 dsh 底座全部能力（模型选择、发送、历史、上下文） | **不搬、不改** dsh 的 React 树，只做 CSS 覆盖 + 外围浮层 |
| 面板自己会「处理人员数据」 | 版块内置 Agent：意图解析 + 工具调用 + 结果渲染（不依赖对话） |
| 右侧对话的结果能在左侧出效果 | 事件桥（只读监听会话区）→ 手动/自动同步 |
| 外观干净 | 皮肤重塑 + 对话框精简（隐藏第三方插件杂项）+ 常用提问气泡 |

**不做（红线）**

1. **不修改 dsh 的 DOM 结构**（除分栏必需的一次"包一层"，见 §4.2）—— 一旦搬走节点，React 事件委托链会断，表现为"按钮点不动、输入不生效、发送按钮永久禁用"。
2. **不写 dsh 自身的存储**（`~/.dsh/storages/*.json`）—— 试过，会话归组不生效还会把会话弄丢，已还原。
3. **不碰 dsh 外壳的 Grid**（`[class*="frame"]` 是 `280px 1160px 0px`）—— 改它会直接搞坏 dsh 侧栏宽度。

---

## 2. 总体架构

```
┌──────────────────────────── dsh web 页面（4080）────────────────────────────┐
│                                                                              │
│  ┌── 侧栏（dsh 原生）──┐   ┌──────────── 中心区（dsh 原生 Grid）────────────┐  │
│  │ 工作台首页           │   │  ┌──── #dsh-wb-shell（我们的容器）─────────┐  │  │
│  │ …                    │   │  │ ┌ wb-shell-left ┐ ┌ wb-shell-right ─┐ │  │  │
│  │ ✅ 任务待办          │   │  │ │ 业务面板       │ │ dsh 原生会话    │ │  │  │
│  │ 💼 内部招聘          │   │  │ │ (React 根)     │ │ (原 centerCol)  │ │  │  │
│  │ 👥 人员信息 ← 入口    │   │  │ │ 指令/轨迹/结果 │ │ 消息/输入/模型  │ │  │  │
│  │ 🔔 消息中心          │   │  │ └────────────────┘ └─────────────────┘ │  │  │
│  │ 工作区分组…          │   │  └────────────────────────────────────────┘  │  │
│  └──────────────────────┘   └──────────────────────────────────────────────┘  │
│      ↑ 注入的分组改造                ↑ 浮层（挂 body，只读定位，不改 DOM）      │
│  · 🦩 业务对话（默认收起+剔除遗留）   · 常用提问抽屉 / 新建对话 / 历史 / 同步按钮 │
└──────────────────────────────────────────────────────────────────────────────┘
```

**三层职责**

| 层 | 归谁 | 内容 |
|---|---|---|
| 底座 | dsh 原生 | 会话、模型、消息流、输入框、工作区/会话树 |
| 外壳 | 我们（插件） | 侧栏入口、shell 容器、浮层（气泡/按钮/历史）、CSS 皮肤与精简 |
| 业务 | 我们（插件） | 人员数据中心、版块 Agent、结果渲染、事件桥 |

**一句话原理**：**我们的东西全是"新加的节点或 CSS 覆盖"，dsh 的东西只做两件"最小侵入"的事 —— ① 给它的中心列外面包一层（分栏必需）；② 在读它 DOM 的基础上打标记/加样式。**

---

## 3. 涉及文件

### 3.1 主改动（唯一需要动的代码文件）

| 文件 | 说明 |
|---|---|
| `custom/dsh-wb-workbench/lib/client.js` | **全部前端改造都在这里**（约 3100 行）。样式常量 + React 组件 + DOM 注入 + 事件桥 + 分栏 + 浮层 |
| `custom/dsh-wb-workbench/cordis.patch.yml` | 插件声明（无需改动） |
| `custom/dsh-wb-workbench/lib/index.js` | 插件宿主侧（无需改动） |

> 改完保存即生效：4080 会热编译插件（首页 `__DSH_BOOT__` 里的 `rev` 会变），**Ctrl+F5 刷新即可，不用重启服务**。

### 3.2 验证/调试脚本（新增，都在 `deploy/tools/`）

| 脚本 | 用途 |
|---|---|
| `probe-e2e.js` | **真实鼠标**端到端：进面板 → 历史 → 新建对话 → 底座新会话 |
| `probe-flash.js` | 采样「可见行数」验证**有没有闪一下**（每 90ms 一次） |
| `probe-bizstay.js` | 展开分组后连续 8 秒观察**会不会被自动折回** |
| `probe-hasrule.js` / `probe-hasrule2.js` | 验证隐藏规则**没有误伤**会话树（`treeBody` 还在、分组数不变） |
| `probe-hidewrap.js` | 注入假会话行验证「精确剔除 + 包裹标记」逻辑 |
| `probe-sidebar-stable.js` | 长跑观察侧栏稳定性 |
| `probe-nobar.js` | 验证状态条已移除 + 手动同步按钮可用 |
| `probe-skin-ab.js` | 皮肤开/关 A/B（对比 computed style，确认"确实改了"） |
| `probe-skin5.js` | dump 消息流真实 DOM 结构（写皮肤前用它对齐 class） |
| `probe-bizexpand.js` / `probe-bizrows.js` | 展开分组、读行明细（排查"这 4 条是什么"） |
| `rpc.js` | 直接调用 dsh RPC（`session.list` / `session.create` 等） |

> 统一依赖：`NODE_PATH=C:/Users/74718/.workbuddy/binaries/node/workspace/node_modules` + 本机 Edge 的 `puppeteer-core`。

### 3.3 环境修复（不属于插件代码，见 §9）

| 位置 | 说明 |
|---|---|
| `~/.dsh/profiles/web/node_modules/@deepseek-ai/*` | 把 web profile 里版本不一致的 65 个包换成指向 core 的 junction（统一到 rc.7），原目录备份为 `_rc8bak/` |

---

## 4. 关键实现原理

### 4.1 侧栏入口注入

- 找到 dsh 侧栏的分组容器，按现有条目的 DOM 结构复制一份「人员信息」入口（`wb-entry`），点击 → `controller.setActive('directory')`。
- 入口与 dsh 自带条目**互斥**：我们和 dsh-code-review / ssh / task-board 等都通过 `data-dsh-*-active` 属性协调，谁激活谁显示。
- **注意**：入口是插进 dsh 侧栏 DOM 的（这是必须的，否则点不到）。为降低风险，只做「插入 + 打标记」，不改动 dsh 自身的节点。

### 4.2 左右分栏：**shell 包一层**（核心）

**为什么不能用另外两种做法**（都踩过）：

| 做法 | 结果 |
|---|---|
| 把 centerCol 搬到自己建的 `position:fixed` 浮层里 | ❌ **React 事件委托链断裂**：按钮点不动、输入框能打字但 state 不更新、发送按钮永久禁用、模型下拉弹不出来 |
| 给 centerCol 硬压 `width:50% + margin-left:50%` | ❌ dsh 外壳是 Grid + `overflow:hidden`，会把会话内部组件裁掉（"Agent 显示不全"） |
| 给 centerCol 加 `padding-left` 预留 | ⚠️ 可用但只是兜底（会话根若是 absolute/fixed 就推不动） |

**采用**：在 centerCol 的**原位**插入我们的 shell，把它**包进去**：

```
dsh 父节点 (grid item)
  └── #dsh-wb-shell            ← 我们插的（顶替 centerCol 的位置，grid 布局不变）
        ├── .wb-shell-left     ← 业务面板（React 根挂这里）
        └── .wb-shell-right    ← dsh 原生 centerCol（move 进来）
```

- `enterShell()`：记录原父节点/兄弟/内联样式 → 原位插 shell → 把 centerCol 移进 `right` → 打 `data-dsh-wb-shell`。
- `exitShell()`：**原样还原**（父节点、兄弟顺序、内联样式），用于关闭面板/切换到不需要分栏的版块。
- DOM 树**仍然连接**（只是多了一层父级），事件委托照常工作 —— 这是与"搬出去"的本质区别。
- 三层保险：① 全程 `try/catch`，失败永久退回 padding 方案（`shellDisabled`）；② 监听 `removeChild/insertBefore/NotFoundError`（React 想操作被移动的节点）→ 立刻 `exitShell`；③ `autoFitChat()`：若会话仍横向溢出（`scrollWidth > clientWidth`），自动把面板收窄（最多 6 次、不写偏好）。

**宽度契约**：`SPLIT_MIN_W=300`（面板最小）/ `SPLIT_MAX_W=720`（面板最大）/ `SPLIT_MIN_CHAT=640`（空间充足时留给会话的最小宽度，与 dsh 自身 640 的契约一致）/ 窄屏让步 `SPLIT_MIN_CHAT_TIGHT=420`。宽度落在 `--wb-split-w` 上，拖动分隔手柄可调，记忆在 localStorage。

### 4.3 状态属性机制（一切定制的开关）

所有定制都用 `document.documentElement` 上的属性做作用域，**避免影响别的页面/别的插件**：

| 属性 | 含义 |
|---|---|
| `data-dsh-wb-active` | 人员信息版块被激活（中心区显示我们的面板） |
| `data-dsh-wb-split` | 进入左右分栏（皮肤/精简/浮层按钮都在这个作用域下） |
| `data-dsh-wb-shell` | shell 模式生效（此时停用 padding 兜底） |
| `data-dsh-wb-split-collapsed` | 面板收起（会话占满） |
| `data-wb-full` | 应急开关：临时显示回被隐藏的原生杂项（`__wbFull(true/false)`） |
| `data-wb-bizgrp="1"` | 该分组行是「业务对话」（未分组改造而来） |
| `data-wb-hide="1"` / `data-wb-hidewrap="1"` | 被剔除的遗留会话行 / 其空包裹 |

> ⚠️ **双刃剑**：作用域属性一旦丢失（比如面板被意外关闭），**整套定制会一起失效**（皮肤、精简、浮层全没了）。排查时先确认属性还在不在。

### 4.4 右侧原生会话皮肤（方案 1 · 重塑）

**纯 CSS 覆盖**，全部限定在 `html[data-dsh-wb-split] [class*="centerCol"] …` 下，选择器用「hash 后缀模糊匹配」（如 `[class*="bubble"]`、`[class*="uV2eYG_card"]`），因为 dsh 的 class 前缀是构建 hash、会变。

| 部位 | 改造 |
|---|---|
| 用户气泡 | 品牌蓝渐变实心 + 白字 + 投影，`18px 18px 6px` 圆角（右下收尖） |
| 助手回复 | 白底卡片 + 左侧 3px 淡蓝细线，行高 1.72 |
| 工具调用 | 「操作卡」：左蓝条 + 浅底 + 12px |
| 输入卡 | 加强投影；`:focus-within` 双层蓝色光晕 |
| 发送键 | 渐变实心圆钮 + 投影 + hover 微抬 |
| 模型选择 | 描边胶囊 + hover 蓝底 |
| 助手卡片标题 | `::before` 伪元素渲染淡蓝 `AGENT` 标签（不插节点） |
| 工具卡状态点 | `::before` 绿色呼吸圆点 |

**关键教训**：第一版做的是"减法"（大圆角改小、浅蓝改浅灰），而 dsh 原生本来就精致 → 用户完全看不出变化。改判定标准：**必须做 A/B 对比 computed style**，确认是"变好看"而不是"变朴素"。

### 4.5 对话框精简

隐藏（可用 `__wbFull(true)` 临时放行）：

| 位置 | 内容 |
|---|---|
| 第三方插件 `dsh-undo-savepoint` | 撤销 / 恢复 / 快照 / 已存 N 份快照（`[class*="u_actions"]`） |
| dsh 顶栏 | `Session log`（`headerUtilities`）、`对话/轨迹` 标签（`[class*="wSkVaW_tabs"]`）、模式选择器（`[class*="cubgiG_seat"]`） |
| 消息流 | `上下文注入 @deepseek-ai/dsh-system-prompt`（`[class*="pC0e7a_root"]`） |
| 底部统计 | 原生长条（`[class*="bi-root"]`）→ 换成我们的一行 `DeepSeek-V4-Flash · 本对话 ¥0.00x [详情 ›]` |
| 顶栏面包屑 | 只留当前会话名（去掉 `工作区 / xxx /` 前缀） |

> ⚠️ **欢迎页（空会话）的「工作区 / 标准模式」不能隐藏** —— 那是空会话下底座唯一的入口，藏了会让欢迎页缺一块（"对话框显示不完整"）。

### 4.6 常用提问浮动气泡（方案 3 · 折叠抽屉）

- 形态：输入框**上方**一行「💡 常用提问 · N」+ 右侧「⌘K / 换一批」；点开浮现分组抽屉（统计/查询/质量/导出）。
- **写回原生输入框**（React 受控组件必须走原生 setter）：

```js
var set = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
set.call(textarea, '按部门统计人数');
textarea.dispatchEvent(new Event('input', { bubbles: true }));
textarea.focus();
```

- 键盘：`Ctrl/⌘+K` 唤起 → `↑↓` 选择 → `↵` 填入 → `Esc` 关闭；点面板外收起。
- 推荐词**跟着左侧版块走**：`PB_LIB` 按模块（directory / tasks / recruitment / _default）分组配置。
- 实现要点：这一层是挂在 `body` 上的 `position:fixed` 独立浮层，**只读**原生输入框位置来对齐，**完全不碰** dsh 的 DOM 树。

### 4.7 同步机制（右侧对话 → 左侧渲染）

**两条通道**

1. **版块内置 Agent**（主）：面板内输入框/chips → `planTool(文本)` 解析意图 → `execTool()` 取数据 → `AgentResult` 渲染。全部在面板内部完成，不依赖对话。
2. **事件桥**（辅）：`MutationObserver` 只读监听中心列，会话里出现人员相关意图（正则 + 姓名匹配）→ 交给同一个 Agent 跑一遍，结果标注「来源：右侧 dsh 会话」。

**手动 / 自动**

- 默认**手动**：右侧出现结果时左侧不动，只在最后一条工具卡下方浮出蓝色的「→ 同步到左侧面板」按钮，点了才同步（点完变绿 `✓ 已同步`，2 秒收起）。
- 顶部曾有一个「数据源状态条」承载自动同步开关，**已按需求移除** → 同步行为固定为手动；应急开关保留为 `window.__wbAutoSync(true|false)`。
- 去重与节流：文本去重 + 1.5 秒节流，避免误触发。

### 4.8 新建对话 / 历史对话

- **新建对话**：**只在本窗口内新建** —— 直接触发底座自己的「新会话」按钮，dsh 在 SPA 内切换，**不刷新页面**。
  （旧做法是「调接口建会话 → 改 localStorage → `location.reload()`」，等于把整个对话框重建，观感很差。）
- **历史对话**：顶栏「新建对话」左边，点开是我们自己的浮层列表（分组名 + 标题 + 当前项高亮），点一项切换（走原生会话行）。**先显示再补内容**：点开立刻有列表，再异步把折叠分组里的会话补进去。

### 4.9 侧栏「业务对话」分组

背景：dsh 只有 2 个已登记工作区（`dsh-playground`、`docs_demo`），**cwd 不在已登记工作区路径下的会话一律落进「未分组」**。我们的业务会话（cwd = `…\dsh-base\biz-workspace`）正好属于这一类，所以直接**把「未分组」这个分组改造成业务专区**（不改 dsh 数据、不碰归组逻辑）：

| 处理 | 做法 |
|---|---|
| 改名 | 藏掉原生「未分组」三个字，叠一个我们的 `🦩 业务对话` 标签 + 数量角标（`position:fixed` 浮层，`pointer-events:none`） |
| 默认收起 | 加载后**只折一次**（见坑 8），用户自己展开后永不干预 |
| 剔除遗留会话 | 标题是「纯 ASCII 短串（目录名）」的行 → 打 `data-wb-hide` 隐藏；其包裹若「整包都被剔除」再打 `data-wb-hidewrap`，**向上爬以 `groupSection` 为边界**（见坑 7） |
| 即时生效 | `MutationObserver`（挂 `document.body`）在**节点插入的同一微任务**里同步剔除 → 永远不会先画出来再消失（见坑 9） |

---

## 5. 代码逻辑详解（`client.js` 分区）

### 5.1 分区地图

| 行区间 | 分区 | 职责 |
|---|---|---|
| 25–32 | 品牌与主题 | 主色/密度等常量 |
| 33–315 | 样式 | **全部 CSS 作为 JS 字符串数组**，`ensureStyle()` 注入 `<style data-wb-style="1">`（可按需 `disabled` 做 A/B） |
| 321–424 | 共享状态 + 接口 | `state`、`api()/post()`、`refreshAll/refreshPeople/...` |
| 425–451 | 模块定义 | `MODULES`、`defaultPrefs`、`enabledIds` |
| 452–820 | 小组件 | `Stat` / `PageDashboard` / `PageTasks` / `PageRecruitment` / `PageDirectory` … |
| 821–1473 | **版块内置 Agent** | `peopleRows` → `planTool` → `execTool` → `runAgent` + `AgentConsole/AgentTrail/AgentResult` |
| 1474–1513 | 面板控制器 | `PanelController`（activeModule 管理 + 与其它插件互斥） |
| 1514–1647 | 侧栏入口 | `mountSidebarEntries` |
| 1648–1841 | 中心列面板 | `mountPanel` / 分栏宽度计算 / `correctSplitGeometry` |
| 1842–1912 | 事件桥 | `startBridge` / `stopBridge`（只读监听会话区） |
| 1913–2068 | **Shell 层** | `ensureShell` / `enterShell` / `exitShell` / `autoFitChat` / `panelHost` |
| 2069–2328 | 常用提问气泡 | `PB_LIB` + `mountPromptBubbles`（折叠抽屉 + 键盘 + 写回原生输入框） |
| 2329–2414 | 同步按钮 | `mountSyncButton`（手动模式浮出按钮） |
| 2415–3036 | **对话框精简 + 新建对话 + 侧栏业务分组** | `newBizSession` / `mountChatTools` / `bizGroupRow` / `pruneBizRows` |
| 3037–结尾 | 插件装配 | `apply()`：`ensureStyle()` → 建 controller → 依次 `mount*()` → 返回 disposer |

### 5.2 几个关键函数的逻辑

**`mountPanel(controller)` —— 面板挂载**

```
ensure():
  if (!controller.isOpen())        → 卸载 React 根 + 移除容器，直接 return   ← 坑 2：否则关了又被建回来
  host = panelHost()               ← shell 生效时是 .wb-shell-left，否则是 centerCol
  if (容器已在 host 里) return
  if (容器还在但换了宿主) 直接 appendChild 搬家（不必重建 React 根）
  否则 createElement + createRoot + render(<WorkbenchPanel/>)
```

**`mountChatTools()` —— 精简 + 新建对话 + 历史 + 侧栏分组**

```
sync()  ← 由 resize / ResizeObserver / MutationObserver / 1.2s 轮询共同触发
  if (now - syncAt < 260) return                    ← 时间戳节流（不要用 busy+rAF，见坑 3）
  split = html 是否有 data-dsh-wb-split
  1) 极简统计条定位（贴输入框下方）
  2) 新建对话 / 历史 按钮定位（贴会话顶栏右侧）
  3) 侧栏业务分组：
       target = bizGroupRow()                       ← 标记优先，textContent 找「未分组」兜底
       if (!weCollapsed) { weCollapsed = true; if (展开) target.click(); }   ← 坑 8
       n = pruneBizRows()                           ← 剔除遗留会话，返回可见业务会话数
       更新角标 + 定位标签
```

**`pruneBizRows()` —— 剔除遗留会话（不节流，供 MO 同步调用）**

```
target = bizGroupRow();  sec = target.closest('[class*="groupSection"]')
for 每个 sessionRow:
    标题匹配 /^[A-Za-z0-9._-]{1,24}$/（纯 ASCII 短串 = 目录名）→ data-wb-hide="1"，否则清除标记并计数
清掉上一轮的 data-wb-hidewrap，再重打：
    for 每个被隐藏的行:
        wrap = row.parentElement
        while (wrap && wrap !== sec):
            if (wrap 里含 projectRow) break        ← 绝不越过分组行
            若 wrap 内还有可见 sessionRow → break  ← 只藏"整包都被剔除"的包裹
            wrap.setAttribute('data-wb-hidewrap','1'); wrap = wrap.parentElement
```

**`startBridge()` —— 事件桥（只读）**

```
MutationObserver 监听 centerCol
  取新增文本 → bridgeIntent() 过滤（长度 4~300；含「统计/部门/找/查/谁/多少/列出/筛选/补全/缺失/分布/人数」或某个真实姓名）
  → 命中且未重复、距上次 >1.5s
     自动模式：立刻 runAgent(text,'chat')
     手动模式：chatBridge.pending = text，并让「同步到左侧面板」按钮浮出
```

**`runAgent(text, source)` —— 一次 Agent 执行**

```
planTool(text)   → { tool:'people.stats'|'people.search'|'people.audit', args:{group|kw} }
execTool(plan, rows) → { stats | bars | table }（纯前端计算，数据来自 state.people）
state.agent = { steps:[{name,args,ms}], result, source, at }
→ emit() 触发面板重渲染（轨迹 + 统计卡 / 分布条 / 风险表）
```

### 5.3 反模式清单（写新代码时照着避）

| 不要写 | 为什么 | 应该写 |
|---|---|---|
| `el.click()` 去模拟用户操作 | `isTrusted=false`，会被"点侧栏就收起"之类逻辑误判 | 判断处加 `if (event.isTrusted === false) return;` |
| `busy` 标志 + `requestAnimationFrame` 包裹同步 | rAF 在后台标签页被暂停 → busy 永不复位 → 同步永久停摆 | 时间戳节流 `if (Date.now()-last < 260) return;` |
| 用 `innerText` 找元素 | 自己的 CSS（如 `font-size:0`）会把它读空 | `data-*` 标记 + `textContent` |
| 宽泛的 `*:has(...)` 去隐藏侧栏元素 | 会命中整个会话树（`treeBody`），整块侧栏消失 | JS 精确判定 + `groupSection` 当边界 |
| 把"该立即隐藏"的逻辑放进节流函数 | 元素会先渲染、几百毫秒后才消失（闪一下） | 抽不节流的小函数，在 MO 回调里同步调用 |
| 一次性动作的标志位"真做了才置位" | 条件不成立时标志永远 false → 用户操作被反复覆盖 | 判定前先置位 |
| 观察器挂 `[class*="sidebarCol"]` | 插件 apply 时侧栏还没挂载 → 等于没挂 | 挂 `document.body` + `subtree:true`，回调里按 target 过滤 |
| CSS 限定在 `html[data-xxx]` 却指望它在任何情况下生效 | 属性一丢，整套定制失效 | 明确哪些必须"始终生效"（如侧栏分组），就别加限定 |

---

## 6. 验证方法（必须做，否则你会以为好了）

**程序化 `element.click()` 不算验证** —— 它 `isTrusted=false`，会绕过真实事件序列，把上面第 1 条那类 bug 全掩盖掉（本项目就因此漏掉了 3 个 bug）。

标准动作（`probe-e2e.js` 是模板）：

```js
const box = await p.evaluate(() => { const k = el.getBoundingClientRect(); return { x: k.left + 60, y: k.top + k.height/2 }; });
await p.mouse.click(box.x, box.y);                                  // 真实鼠标
const k = el.getBoundingClientRect();                                // rect 非 0 才算没被 display:none
const hit = document.elementFromPoint(k.x + k.width/2, k.y + 20);    // 命中自己 → 没被遮挡
window.__wbMarker = 42;                                              // 点完还在 → 页面没刷新
```

**必查项**：目标 rect 非 0；`elementFromPoint` 命中自身；关键 `documentElement` 属性（如 `data-dsh-wb-split`）没丢；`pageerror` 为空；**行为类指标要采样**（如"有没有闪"要每 90ms 采样一次，而不是只看终态）。

另外两个常用钩子：

```js
window.__wbChatSync()      // 立即跑一次精简/分组同步（排查用）
window.__wbFull(true|false)// 临时显示/隐藏被精简掉的原生杂项
```

---

## 7. 本次实测记录

| 项目 | 结果 |
|---|---|
| 分栏布局 | 面板 464px / 会话 695px，`scrollWidth === clientWidth`（**零裁切**） |
| 底座能力 | 输入框可输入、模型菜单可选（`DeepSeek-V4-Flash / V4-Pro`）、消息可发送并收到回复 |
| 版块 Agent | 「按部门统计」→ 总人数 10、5 个部门、最大技术中台占比 20%，约 143ms |
| 事件桥 | 右侧「按工作地统计人数」→ 左侧渲染 深圳 4 / 杭州 2 / 北京 2 / 上海 2，标注「来源：右侧 dsh 会话」 |
| 手动同步 | 默认手动：左侧不动 → 按钮浮出 → 点击后渲染 4 张统计卡 → 按钮变绿 |
| 常用提问 | 浮层 659px 贴在输入框上方（浮层底 294 / 输入区顶 329）；`↓↓+↵` 后原生 `textarea.value` = 目标句子；`Ctrl+K` 唤起 |
| 新建对话 | 点击后 `__wbMarker` 仍在（**未刷新**），sessionId 由 `cf8d44c9…` → `c31c1710…` |
| 底座新会话 | 面板彻底移除（`panelExists=false`），左侧不残留 |
| 业务分组 | 刷新后默认收起；手动展开后连续 8 秒不掉；4 条遗留会话在第 0 次采样即不可见（**无闪烁**） |
| 稳定性 | 连续 39 秒多轮同步，侧栏尺寸/分组数不变；全程 `pageerror` 为 0 |

---

## 8. 已知限制与待办

1. **皮肤依赖 dsh 的 class 后缀模糊匹配**（`bubble`、`uV2eYG_input` 这类）。dsh 升级换了前缀 → 皮肤自动失效回到原样，**功能不受影响**，需重新对齐。
2. **业务分组里目前是空的**：`未分组` 中的 4 条（`dsh-base`×2 16 天前、`dsh-playground`×2 40 天前）都是历史遗留，按规则被剔除；空会话（含我为调试建的 5 条 `biz-workspace` 空会话）dsh 不显示。**等业务会话产生内容后即会出现**。
   - 可选清理：删掉这些僵尸会话，或让"空分组自动隐藏"。
3. **老会话 `session-4c8212ca-…`（8/17）** 的历史数据是旧格式，打开可能异常；新建会话正常。
4. 未接真实接口：评估系统 / 数据看板 / 模型配置仍是占位；biz-web（4000）尚未落地这套 11 版块。
5. 侧栏入口目前只做了「人员信息」带分栏（`SPLIT_MODULES = { directory: true }`），其它版块是整区接管模式。

---

## 9. 附录 A：环境修复（dsh 版本漂移）

**症状**：模型菜单报 `模型操作失败：internal: resume failed … agent-presets: refusing to compose an unscoped context`；消息流被"历史加载失败"占位。

**根因**：`~/.dsh/profiles/web/node_modules/@deepseek-ai/` 里 **140 个包：66 个 rc.8 + 64 个 rc.7**（两次升级残留），core 侧 195 个包全是 rc.7。两个致命错位：

1. **scope symbol 双实例**：`dsh-scope` 里写的是 `const kScope = Symbol("dsh.scope")`（不是 `Symbol.for()`），**两份副本各生成不同的 symbol** → 一边写标记、另一边读出来是 `undefined` → "unscoped context"。这也解释了为什么单独把 4 个 agent 包降级无效。
2. **history schema 错位**：`maxImageDimension: number`（必填）只存在于 web 侧的 `dsh-host-apiproxy`(rc.8) → 每条历史校验失败 → 消息流被错误占位。

**修法**：web 侧 65 个版本不一致的包全部替换为**指向 core 的 junction**（同一份代码 = 单一实例），原目录原地改名备份在 `_rc8bak/`（可一键回滚）。脚本：`deploy/tools/unify-profile.js`（含单包修复版 `fix-scope.js`）。

**验证**：`session.create` 返回 `ok, agentPreset:"standard"`；发消息收到回复；模型菜单出 `DeepSeek-V4-Flash / V4-Pro` 且可选；消息流正常渲染；零报错。

> ⚠️ 本环境每次重启 dsh 会被沙箱的删除保护拦掉 `~/.dsh/task-board/ledger-v2.lock` 导致启动 502 —— 重启前先把它挪走（`mv ledger-v2.lock ledger-v2.lock.bak-$(date +%H%M)`）。目标用户机器不受影响。

---

## 10. 附录 B：回滚方式

| 想回滚 | 做法 |
|---|---|
| 只回滚界面定制 | 控制台执行 `localStorage.setItem('wb-workbench-disabled','1')` 后刷新 → 插件完全停用；`removeItem` 恢复 |
| 临时看回原生杂项 | `__wbFull(true)` / `__wbFull(false)` |
| 回滚 dsh 版本统一 | 把 `~/.dsh/profiles/web/node_modules/@deepseek-ai/_rc8bak/*` 改回原名（覆盖 junction） |
| 回滚插件代码 | `client.js` 单文件，用版本管理回退即可（无构建步骤，保存即生效） |
