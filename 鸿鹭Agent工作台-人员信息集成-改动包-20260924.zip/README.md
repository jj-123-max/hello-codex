# 鸿鹭 Agent 工作台 ·「人员信息 + Agent 对话」改动包

| 项 | 值 |
|---|---|
| 打包日期 | 2026-09-24 |
| 来源工程 | `demo-9-7/dsh-base` |
| **只含** | 本次**改动/新增**的文件 + 说明文档 + 设计稿 |
| **不含** | 工程全量（`src/`、`biz-web/`、`node_modules/`、`dist/`、`data/`、`logs/` 等一律没打） |
| 规模 | 30 个文件 / 520 KB |

---

## 一、改动清单（这是全部，没有遗漏也没有多余的）

### 被修改的既有文件（**只有 1 个**）

| 文件 | 说明 |
|---|---|
| `custom/dsh-wb-workbench/lib/client.js` | 本次前端改造的**全部代码**都在这里（约 3100 行）。其余 4 个插件文件（`index.js`/`data.js`/`package.json`/`cordis.patch.yml`）**一个字没改**，所以没打进来 |

### 新增的文档

| 文件 | 说明 |
|---|---|
| `docs/人员信息Agent集成-改造说明.md` | 原理 / 涉及文件 / 代码逻辑 / 踩坑 / 验证方法 / 环境修复 / 回滚 |
| `01-说明文档/…改造说明.html` | 同上内容的 HTML 阅读版（同一份，用来看） |

### 新增的脚本（`deploy/tools/`，本次调试与验证用）

| 脚本 | 用途 |
|---|---|
| `probe-e2e.js` | **真实鼠标**端到端：进面板 → 历史 → 新建对话 → 底座新会话 |
| `probe-flash.js` | 采样「可见行数」验证有没有"闪一下又消失"（每 90ms） |
| `probe-bizstay.js` | 展开分组后连续 8 秒观察会不会被自动折回 |
| `probe-hasrule.js` / `probe-hasrule2.js` | 验证隐藏规则没误伤会话树（`treeBody` 还在、分组数不变） |
| `probe-hidewrap.js` | 验证「精确剔除 + 包裹标记」逻辑 |
| `probe-sidebar-stable.js` | 侧栏长跑稳定性 |
| `probe-bizexpand.js` / `probe-bizrows.js` | 展开分组 / 读行明细 |
| `probe-nobar.js` | 状态条已移除 + 手动同步按钮可用 |
| `probe-skin-ab.js` | 皮肤开/关 A/B（computed style 对比） |
| `probe-skin5.js` | dump 消息流真实 DOM（写皮肤前对齐 class 用） |
| `probe-agent.js` / `probe-bridge.js` / `probe-prompts.js` / `probe-clean.js` | 版块 Agent / 事件桥 / 提问气泡 / 杂项清理的验证 |
| `rpc.js` | 直调 dsh RPC（`session.list` / `session.create` …） |
| `unify-profile.js` / `fix-scope.js` | 环境修复：把 web profile 的 @deepseek-ai 包统一到核心版本（见改造说明 §9） |
| `biz-workspace.js` | 登记业务工作区（实验用，**结论：这条路不通**，见改造说明 §4.9） |
| `md2html.js` | 零依赖 md→html（写文档用） |
| `adjust-paths.js` | **换机器先跑这个**：把脚本里的 `C:\Users\74718`、Edge 路径、`BIZ_CWD` 换成本机的 |

> 另有约 40 个一次性排查脚本（`probe-model*.js`、`probe-skin*.js`、`probe-ls*.js` 等）没打进来，属于排障过程的中间产物，需要的话我再单独给你。

### 新增的设计稿（`03-设计稿/`）

`人员信息-Agent集成方案` / `Agent对话框定制三方案` / `对话框常用提问气泡-三方案` / `对话框隔离与精简方案` / `鸿鹭工作台-工程对齐版`

---

## 二、怎么合并回工程

`02-改动文件/` 里是**按工程原有相对路径**放的，直接覆盖即可：

```bash
# 在工程根目录（dsh-base）执行
cp -r 02-改动文件/custom   ./
cp -r 02-改动文件/deploy   ./
cp -r 02-改动文件/docs     ./
```

改完保存即生效（dsh 会热编译插件），浏览器 **Ctrl+F5** 刷新即可；**不需要重启服务**。

换机器后请先跑一次路径修正（可加 `--dry` 先看）：

```bash
node deploy/tools/adjust-paths.js --dry
node deploy/tools/adjust-paths.js
```

---

## 三、这次改造的铁律（改代码前先看，能省掉我踩过的所有弯路）

1. **不搬 dsh 的 DOM** —— 会切断 React 事件委托链（症状：按钮点不动、输入不更新、发送永久禁用）。分栏只能用「在 centerCol **原位**插一层 shell 把它包进去」。
2. **不写 dsh 的存储**（`~/.dsh/storages/*.json`）—— 会话归组不生效，还会弄丢会话。
3. **不碰 dsh 外壳 Grid**（`[class*="frame"]`）。
4. 定制一律限定在 `html[data-dsh-wb-*]` 作用域，并想清楚"哪些必须始终生效"。
5. **程序化 `element.click()` 不算验证** —— 必须真实鼠标 + `elementFromPoint`，行为类指标要采样。

> 9 条坑的现象/原因/解法，见 `01-说明文档/…改造说明.md` §5.3 与 §6。

---

## 四、包内**没有**的东西（避免你找）

- 工程源码：`src/`（4000 网关）、`biz-web/`（原工作台前端）、`scripts/`、`installer/`
- 运行环境与产物：`node_modules/`、`dist/`、`dsh-home/`、`logs/`、`probe/`
- 插件其余 4 个未改动文件（`lib/index.js`、`lib/data.js`、`package.json`、`cordis.patch.yml`）
- 业务数据（`data/biz/*.json`）、本机配置（`config.json`）
- 实测截图（原包里有 11 张，本次按"只要改动文件和文档"的要求去掉了；需要可再给）

这些在你本机工程里都是原样的，不需要从包里拿。
